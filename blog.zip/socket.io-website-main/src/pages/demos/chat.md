---
title: Chat
---

<p>
  <a
    href="https://socketio-chat-h9jt.herokuapp.com/"
    style={{
      textDecoration: "none",
      display: "inline-block",
      background: "#000",
      color: "#fff",
      fontSize: 12,
      fontWeight: "bold",
      padding: "3px 10px"
    }}
  >
    https://socketio-chat-h9jt.herokuapp.com/
  </a>
  <a
    href="https://github.com/socketio/socket.io/tree/main/examples/chat"
    style={{ float: "right", fontSize: 12 }}
  >
    View source code
  </a>
</p>

<script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/2.3.0/socket.io.js"></script>
<iframe src="https://socketio-chat-h9jt.herokuapp.com/" width="100%" height="480" scrolling="no" class="iframe-class" frameBorder="0"></iframe>
