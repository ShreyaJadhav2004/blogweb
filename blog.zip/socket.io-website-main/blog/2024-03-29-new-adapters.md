---
title: Three new adapters
slug: /three-new-adapters/
authors:
  - darrachequesne
---

Hello everyone!

I'm happy to announce that we provide 3 new official adapters:

- the [Google Cloud Pub/Sub adapter](/docs/v4/gcp-pubsub-adapter/)
- the [AWS SQS adapter](/docs/v4/aws-sqs-adapter/)
- the [Azure Service Bus adapter](/docs/v4/azure-service-bus-adapter/)

Any feedback is welcome!
